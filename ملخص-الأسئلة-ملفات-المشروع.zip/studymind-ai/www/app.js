const $=id=>document.getElementById(id);
const KEY='mulakhas-alasila-v1';
let db=load(), currentAnalysis=null, cards=[], cardIndex=0, quiz=[];
function load(){try{return JSON.parse(localStorage.getItem(KEY))||{notes:[],cards:[],quizzes:[]}}catch{return{notes:[],cards:[],quizzes:[]}}}
function persist(){localStorage.setItem(KEY,JSON.stringify(db));renderStats();renderNotes()}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function sentences(t){return t.replace(/\r/g,'').split(/(?<=[.!؟?。])\s+|\n+/).map(x=>x.trim()).filter(x=>x.length>15)}
function classify(t){
 const out=[];
 const rules=[
 ['تعريف',/(تعريف|هو عبارة عن|هي عبارة عن|هو كل|هي كل|يُعرّف|تعرف على أنه|الوحدة الأساسية)/i],
 ['تعليل',/(علل|بسبب|لأن|نتيجةً لـ|يؤدي إلى|يرجع ذلك|بسبب أن)/i],
 ['تاريخ',/(\d{1,4}[\/\-]\d{1,2}[\/\-]\d{1,4}|عام\s+\d{2,4}|سنة\s+\d{2,4}|في القرن|هجري|ميلادي)/i],
 ['مسألة',/(احسب|أوجد|حل المعادلة|ما قيمة|كم يساوي|إذا كان.*فإن)/i],
 ['قانون',/(القانون|المعادلة|يساوي|=\s*\d|قانون نيوتن)/i],
 ['تعداد',/(أنواع|أقسام|مراحل|يتكون من|تتكون من|أولاً|ثانياً|ثالثاً)/i],
 ['سؤال وجواب',/(ما هو|ما هي|لماذا|كيف|اذكر|عدد|قارن)/i]
 ];
 for(const [name,re] of rules) if(re.test(t)) out.push(name);
 return out.length?out:['معلومات عامة'];
}
function analyze(t){
 const ss=sentences(t), cats=[...new Set(ss.flatMap(classify))];
 const ranked=ss.map((s,i)=>({s,i,score:(s.length>35?1:0)+(classify(s).some(c=>c!=='معلومات عامة')?2:0)+(/\d/.test(s)?1:0)})).sort((a,b)=>b.score-a.score);
 const summary=(ranked.slice(0,Math.min(4,ranked.length)).sort((a,b)=>a.i-b.i).map(x=>'• '+x.s)).join('\n')||t.slice(0,350);
 const extracted=ss.filter(s=>classify(s).some(c=>c!=='معلومات عامة')).slice(0,12);
 return {text:t,categories:cats,summary,extracted,created:new Date().toISOString()};
}
function showAnalysis(a){
 $('analysisOutput').classList.remove('hidden');
 $('categories').innerHTML=a.categories.map(c=>`<span class="chip">${esc(c)}</span>`).join('');
 $('summary').textContent=a.summary;
 $('extracted').innerHTML=a.extracted.length?a.extracted.map(s=>`<div class="extract-item">${esc(s)} <small>— ${esc(classify(s).join('، '))}</small></div>`).join(''):'<div>لم يتم العثور على عناصر واضحة؛ جرّب نصاً أطول أو أوضح.</div>';
}
$('analyzeBtn').onclick=()=>{const t=$('sourceText').value.trim();if(!t)return alert('أدخل نصاً أولاً.');currentAnalysis=analyze(t);showAnalysis(currentAnalysis)};
$('clearText').onclick=()=>{$('sourceText').value='';$('analysisOutput').classList.add('hidden');currentAnalysis=null};
$('txtFile').onchange=async e=>{const f=e.target.files[0];if(f){$('sourceText').value=await f.text();e.target.value=''}};
$('saveNote').onclick=()=>{if(!currentAnalysis)return;db.notes.unshift({id:uid(),title:currentAnalysis.text.split(/\n/)[0].slice(0,55)||'ملاحظة جديدة',...currentAnalysis});persist();alert('تم حفظ الملاحظة على الجهاز.')};
function makeCardsFrom(a){
 const ss=sentences(a.text), out=[];
 for(const s of ss){
  let m=s.match(/^(?:ما هو|ما هي|عرّف|عرف|ما المقصود بـ)\s*(.+?)[؟?]?\s*[:：-]\s*(.+)$/);
  if(m)out.push({front:m[1].trim(),back:m[2].trim()});
  else if(/^(.*?)(?:هو|هي)\s+(.{15,})$/.test(s)&&/(الخلية|الطاقة|القوة|التفاعل|التاريخ|القانون|المادة)/.test(s)){
   const z=s.match(/^(.*?)\s+(?:هو|هي)\s+(.+)$/);if(z)out.push({front:'عرّف: '+z[1],back:z[2]});
  }
  else if(s.length>35)out.push({front:'ما الفكرة الأساسية في العبارة التالية؟\n'+s.slice(0,115),back:s});
 }
 return out.slice(0,20);
}
$('makeCards').onclick=()=>{if(!currentAnalysis)return;const fresh=makeCardsFrom(currentAnalysis);if(!fresh.length)return alert('لم أستطع إنشاء بطاقات من هذا النص.');db.cards.unshift(...fresh.map(c=>({...c,id:uid(),known:false})));cards=db.cards;cardIndex=0;persist();renderCard();switchTab('review')};
function renderCard(){const area=$('flashcardArea');if(!db.cards.length){area.className='empty';area.textContent='لا توجد بطاقات بعد. حلّل نصاً ثم اختر «إنشاء بطاقات».';return}
 cardIndex=Math.min(cardIndex,db.cards.length-1);const c=db.cards[cardIndex];area.className='';area.innerHTML=`<div class="flashcard" id="flipCard"><div class="question">${esc(c.front)}</div><div class="answer">${esc(c.back)}</div></div><div class="flash-actions"><button class="btn ghost" id="prevCard">السابق</button><button class="btn secondary" id="flipBtn">إظهار الإجابة</button><button class="btn primary" id="knownBtn">أعرفها ✓</button><button class="btn ghost" id="nextCard">التالي</button></div><p style="text-align:center;color:#879bb4;font-size:11px">${cardIndex+1} / ${db.cards.length} • ${c.known?'تمت مراجعتها':'تحتاج مراجعة'}</p>`;
 $('flipBtn').onclick=()=>{$('flipCard').classList.toggle('show');$('flipBtn').textContent=$('flipCard').classList.contains('show')?'إخفاء الإجابة':'إظهار الإجابة'};
 $('knownBtn').onclick=()=>{c.known=true;persist();cardIndex=(cardIndex+1)%db.cards.length;renderCard()};
 $('prevCard').onclick=()=>{cardIndex=(cardIndex-1+db.cards.length)%db.cards.length;renderCard()};
 $('nextCard').onclick=()=>{cardIndex=(cardIndex+1)%db.cards.length;renderCard()};
}
$('makeQuiz').onclick=()=>{if(!currentAnalysis)return;const qs=makeCardsFrom(currentAnalysis).slice(0,8);if(!qs.length)return alert('النص لا يحتوي معلومات كافية لإنشاء اختبار.');quiz=qs.map((c,i)=>({q:c.front,a:c.back,opts:[c.back,'لا شيء مما سبق','جميع الإجابات خاطئة','معلومة غير مرتبطة'].sort(()=>Math.random()-.5)}));db.quizzes.unshift({id:uid(),count:quiz.length,date:new Date().toISOString()});persist();renderQuiz();switchTab('review')};
function renderQuiz(){if(!quiz.length){$('quizArea').innerHTML='';return}$('quizArea').innerHTML='<h3 style="margin-top:24px">اختبار تدريبي</h3>'+quiz.map((q,i)=>`<div class="quiz-card"><h3>${i+1}. ${esc(q.q)}</h3>${q.opts.map(o=>`<button class="option" data-q="${i}" data-a="${encodeURIComponent(o)}">${esc(o)}</button>`).join('')}<div id="feedback${i}" style="font-size:12px;margin-top:6px"></div></div>`).join('');
 document.querySelectorAll('.option').forEach(b=>b.onclick=()=>{const i=+b.dataset.q,o=decodeURIComponent(b.dataset.a),ok=o===quiz[i].a;document.querySelectorAll(`.option[data-q="${i}"]`).forEach(x=>{x.disabled=true;if(decodeURIComponent(x.dataset.a)===quiz[i].a)x.classList.add('correct')});if(!ok)b.classList.add('wrong');$('feedback'+i).textContent=ok?'إجابة صحيحة':'الإجابة الصحيحة: '+quiz[i].a});
}
function switchTab(id){document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));if(id==='review')renderCard();if(id==='library')renderNotes()}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));
$('searchBtn').onclick=doSearch;$('searchInput').onkeydown=e=>{if(e.key==='Enter')doSearch()};
function doSearch(){const q=$('searchInput').value.trim().toLowerCase();if(!q)return;const hits=[];for(const n of db.notes){const text=n.text.toLowerCase();let at=0;while((at=text.indexOf(q,at))!==-1){hits.push({n,excerpt:n.text.slice(Math.max(0,at-90),Math.min(n.text.length,at+q.length+130))});at+=q.length;if(hits.length>40)break}}
 $('searchResults').innerHTML=hits.length?hits.map(h=>`<div class="hit"><b>${esc(h.n.title)}</b><p>…${esc(h.excerpt)}…</p><small>المصدر: ملاحظة محفوظة • صفحة غير محددة</small></div>`).join(''):'<div class="empty">لا توجد نتائج مطابقة.</div>'}
function renderStats(){$('cardCount').textContent=db.cards.length;$('noteCount').textContent=db.notes.length;$('quizCount').textContent=db.quizzes.length}
function renderNotes(){$('notesList').innerHTML=db.notes.length?db.notes.map(n=>`<div class="note"><div><b>${esc(n.title)}</b><small>${new Date(n.created).toLocaleDateString('ar')}</small></div><button class="danger" data-del="${n.id}">حذف</button></div>`).join(''):'<div class="empty">مكتبتك فارغة. احفظ أول ملاحظة من صفحة تحليل النص.</div>';document.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{if(confirm('حذف هذه الملاحظة؟')){db.notes=db.notes.filter(n=>n.id!==b.dataset.del);persist()}})}
function download(name,content,type){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
$('exportJson').onclick=()=>download('ملخص-الأسئلة-نسخة-احتياطية.json',JSON.stringify(db,null,2),'application/json');
$('exportTxt').onclick=()=>download('ملخص-الأسئلة-ملاحظات.txt',db.notes.map(n=>'# '+n.title+'\n'+n.text).join('\n\n---\n\n'),'text/plain;charset=utf-8');
$('importJson').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const x=JSON.parse(await f.text());if(!Array.isArray(x.notes)||!Array.isArray(x.cards))throw Error();db={notes:x.notes,cards:x.cards,quizzes:Array.isArray(x.quizzes)?x.quizzes:[]};persist();alert('تم استيراد النسخة الاحتياطية.')}catch{alert('ملف النسخة الاحتياطية غير صالح.')}e.target.value=''};
renderStats();renderNotes();renderCard();renderQuiz();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
