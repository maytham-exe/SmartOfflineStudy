package com.smartstudy.offline

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.text.InputType

class MainActivity : Activity() {
    private lateinit var store: StudyStore
    private lateinit var input: EditText
    private lateinit var output: TextView
    private val pickCode = 81

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = StudyStore(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,24,20,20); setBackgroundColor(0xFFF7F8FC.toInt()) }
        root.addView(TextView(this).apply { text = "Smart Offline Study"; textSize=24f; setTypeface(null,Typeface.BOLD); setTextColor(0xFF172554.toInt()) })
        root.addView(TextView(this).apply { text = "مصنّف ومساعد دراسة يعمل دون إنترنت"; textSize=14f; setPadding(0,4,0,16) })
        input = EditText(this).apply { hint="الصق فقرة أو سؤالاً دراسياً هنا..."; minLines=5; gravity=48; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        root.addView(input, LinearLayout.LayoutParams(-1,0,1f))
        addButton(root,"تصنيف وتحليل") { analyze() }
        addButton(root,"استيراد كتاب PDF أو TXT") { openFile() }
        addButton(root,"اسأل الكتب المضافة") { answerBook() }
        addButton(root,"إنشاء بطاقة مراجعة") { flashcard() }
        addButton(root,"تلخيص الفقرة") { summarize() }
        addButton(root,"إنشاء اختبار سريع") { makeQuiz() }
        output = TextView(this).apply { textSize=16f; setTextColor(0xFF202938.toInt()); setPadding(0,16,0,12); textIsSelectable=true }
        val scroll = ScrollView(this); scroll.addView(output)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1.3f))
        setContentView(root)
    }
    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() } })
    }
    private fun analyze() {
        val text=input.text.toString().trim(); if(text.isBlank()){ show("أدخل نصاً أولاً."); return }
        val c=StudyEngine.classify(text)
        store.saveNote(text,c.type.label)
        show("التصنيف: ${c.type.label}\nثقة المؤشرات: ${(c.confidence*100).toInt()}%\nالكلمات المفتاحية: ${c.keywords.joinToString("، ")}")
    }
    private fun openFile() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="*/*"; putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/pdf","text/plain")) }
        startActivityForResult(i,pickCode)
    }
    @Deprecated("Legacy callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==pickCode && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            try {
                val name=uri.lastPathSegment?.substringAfterLast('/') ?: "كتاب"
                val chunks=DocumentImporter.read(this,uri,name)
                store.addChunks(chunks)
                show("تم استيراد $name بنجاح. عدد المقاطع: ${chunks.size}\nيمكنك الآن طرح سؤال للبحث داخل محتوى الكتاب.")
            } catch(e:Exception) { show("تعذر استيراد الملف: ${e.message ?: "خطأ غير معروف"}") }
        }
    }
    private fun answerBook() {
        val q=input.text.toString().trim(); if(q.isBlank()){show("اكتب سؤالاً للبحث في الكتب.");return}
        val a=StudyEngine.answerFromBooks(q,store.chunks())
        val src=a.source?.let { "\n\nالمصدر: ${it.document}${it.page?.let { p -> " – صفحة $p" } ?: ""}" } ?: ""
        show("${a.answer}$src")
    }
    private fun flashcard() {
        val t=input.text.toString().trim(); if(t.isBlank()){show("أدخل فقرة لإنشاء بطاقة.");return}
        val (q,a)=StudyEngine.makeFlashcard(t); show("بطاقة مراجعة\n\nالسؤال: $q\n\nالإجابة: $a")
    }
    private fun summarize() { val t=input.text.toString().trim(); show(if(t.isBlank()) "أدخل فقرة للتلخيص." else StudyEngine.summary(t)) }
    private fun makeQuiz() {
        val t=input.text.toString().trim(); if(t.isBlank()){show("أدخل فقرة لإنشاء اختبار.");return}
        val items=StudyEngine.quiz(t)
        if(items.isEmpty()){show("النص قصير جداً لإنشاء اختبار.");return}
        val (question,choices)=items.first()
        val correct=choices.first()
        AlertDialogBuilder.show(this, question, choices, correct) { result ->
            show(if(result==correct) "إجابة صحيحة." else "الإجابة الصحيحة: $correct")
        }
    }
    private fun show(s:String){ output.text=s }
}
