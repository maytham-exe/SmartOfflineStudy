package com.smartstudy.offline

import java.text.Normalizer
import kotlin.math.sqrt

enum class StudyType(val label: String) { DEFINITION("تعريف"), REASON("تعليل"), PROBLEM("مسألة"), DATE("تاريخ") }
data class Classification(val type: StudyType, val confidence: Double, val keywords: List<String>)
data class SourceChunk(val document: String, val page: Int?, val text: String)
data class BookAnswer(val answer: String, val source: SourceChunk?, val confidence: Double)

/** Small rule + TF-IDF style local classifier. No network, model download or analytics. */
object StudyEngine {
    private val stop = setOf("من","في","على","الى","إلى","عن","ما","ماذا","هو","هي","هذا","هذه","ذلك","التي","الذي","و","او","أو","ثم","كان","تكون","مع","قد","تم","أن","إن","لا","لم","لن","كل","بها","به","له","لها","كما")
    private val patterns = mapOf(
        StudyType.DEFINITION to listOf("يعرف", "تعريف", "هو عبارة عن", "ما المقصود", "يطلق على", "هو", "هي"),
        StudyType.REASON to listOf("علل", "فسر", "ما سبب", "لماذا", "بسبب", "نتيجة", "علّة", "لأن", "لان"),
        StudyType.PROBLEM to listOf("احسب", "أوجد", "اوجد", "حل", "كم يساوي", "معادلة", "يساوي", "×", "÷", "+", "=", "مسألة"),
        StudyType.DATE to listOf("متى", "في عام", "عام", "سنة", "تاريخ", "هجري", "ميلادي", "قبل الميلاد", "بعد الميلاد")
    )
    private val stopWords = stop
    fun normalize(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFKC)
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي')
        .replace('ؤ','و').replace('ئ','ي').replace('ة','ه').lowercase()

    fun tokens(s: String): List<String> = normalize(s)
        .split(Regex("[^\\p{L}\\p{N}]+"))
        .filter { it.length > 1 && it !in stopWords }

    fun classify(text: String): Classification {
        val n = normalize(text)
        val scores = StudyType.values().associateWith { type ->
            patterns[type]!!.sumOf { p ->
                val needle = normalize(p)
                when {
                    n.contains(needle) && needle.length > 2 -> if (needle.contains(" ")) 3.0 else 1.5
                    n.contains(needle) -> 1.0
                    else -> 0.0
                }
            } + when(type) {
                StudyType.DATE -> Regex("\\b(1[0-9]{3}|20[0-9]{2}|[0-9]{1,2}/[0-9]{1,2}/[0-9]{2,4})\\b").findAll(n).count() * 2.0
                StudyType.PROBLEM -> Regex("[0-9]\\s*[=+×÷*/-]\\s*[0-9]").findAll(n).count() * 2.5
                else -> 0.0
            }
        }
        val ranked = scores.entries.sortedByDescending { it.value }
        val top = ranked.first()
        val total = ranked.sumOf { it.value }
        val confidence = if (top.value == 0.0) 0.25 else (top.value / total).coerceIn(0.25, 0.99)
        return Classification(top.key, confidence, keywords(text))
    }

    /** Lightweight frequency ranking approximates TF-IDF for a single paragraph. */
    fun keywords(text: String, limit: Int = 6): List<String> =
        tokens(text).groupingBy { it }.eachCount().entries
            .sortedWith(compareByDescending<Map.Entry<String,Int>> { it.value }.thenByDescending { it.key.length })
            .take(limit).map { it.key }

    fun summary(text: String, maxSentences: Int = 2): String {
        val sentences = text.split(Regex("(?<=[.!؟])\\s+|\\n+")).map { it.trim() }.filter { it.length > 15 }
        if (sentences.size <= maxSentences) return text.trim()
        val all = tokens(text).toSet()
        return sentences.mapIndexed { i, s ->
            val ts = tokens(s)
            i to (if (ts.isEmpty()) 0.0 else ts.count { it in all }.toDouble() / sqrt(ts.size.toDouble()))
        }.sortedByDescending { it.second }.take(maxSentences).sortedBy { it.first }.joinToString(" ") { sentences[it.first] }
    }

    /** Answers only from user-imported book passages. Returns no fabricated answer on weak match. */
    fun answerFromBooks(question: String, chunks: List<SourceChunk>): BookAnswer {
        if (chunks.isEmpty()) return BookAnswer("لم تتم إضافة كتب بعد. استورد ملف PDF أو TXT أولاً.", null, 0.0)
        val q = tokens(question).toSet()
        if (q.isEmpty()) return BookAnswer("اكتب سؤالاً يتضمن كلمات واضحة للبحث في الكتب.", null, 0.0)
        val scored = chunks.map { chunk ->
            val words = tokens(chunk.text)
            val counts = words.groupingBy { it }.eachCount()
            val score = q.sumOf { term -> (counts[term] ?: 0).toDouble() / (1.0 + kotlin.math.ln(1.0 + words.size)) }
            chunk to score
        }.sortedByDescending { it.second }
        val best = scored.first()
        if (best.second < 0.18) return BookAnswer("لم أجد فقرة موثوقة بما يكفي في الكتب المضافة. جرّب صياغة أخرى أو أضف المصدر.", null, best.second)
        val excerpt = best.first.text.trim().take(1200)
        return BookAnswer(excerpt, best.first, best.second)
    }

    fun makeFlashcard(text: String): Pair<String,String> {
        val clean = text.trim()
        val type = classify(clean).type
        val question = when(type) {
            StudyType.DEFINITION -> "ما تعريف: ${keywords(clean,3).joinToString("، ")}؟"
            StudyType.REASON -> clean.take(180).let { if (it.endsWith("؟")) it else "علّل: $it" }
            StudyType.PROBLEM -> "حل المسألة أو وضّح خطواتها: ${clean.take(150)}"
            StudyType.DATE -> "ما الحدث أو التاريخ المرتبط بـ: ${keywords(clean,3).joinToString("، ")}؟"
        }
        return question to clean
    }

    fun quiz(text: String): List<Pair<String,List<String>>> {
        val kws = keywords(text, 4)
        if (kws.isEmpty()) return emptyList()
        return kws.map { word -> "اختر الكلمة المفتاحية الواردة في النص: ${summary(text,1).take(100)}" to
            listOf(word, "خيار غير صحيح ١", "خيار غير صحيح ٢", "خيار غير صحيح ٣") }
    }
}
