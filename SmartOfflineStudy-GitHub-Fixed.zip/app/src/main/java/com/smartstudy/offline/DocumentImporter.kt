package com.smartstudy.offline

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

object DocumentImporter {
    fun read(context: Context, uri: Uri, displayName: String): List<SourceChunk> {
        val mime = context.contentResolver.getType(uri) ?: ""
        return when {
            mime.contains("pdf") || displayName.endsWith(".pdf", true) -> readPdf(context, uri, displayName)
            else -> readText(context, uri, displayName)
        }
    }
    private fun readText(context: Context, uri: Uri, name: String): List<SourceChunk> {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        require(text.isNotBlank()) { "الملف فارغ أو تعذر قراءة ترميزه." }
        return text.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }.map { SourceChunk(name, null, it) }
    }
    private fun readPdf(context: Context, uri: Uri, name: String): List<SourceChunk> {
        PDFBoxResourceLoader.init(context)
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذر فتح PDF")
        val doc = PDDocument.load(bytes)
        try {
            val stripper = PDFTextStripper()
            return (1..doc.numberOfPages).mapNotNull { page ->
                stripper.startPage = page; stripper.endPage = page
                stripper.getText(doc).trim().takeIf { it.isNotBlank() }?.let { SourceChunk(name, page, it) }
            }
        } finally { doc.close() }
    }
}
