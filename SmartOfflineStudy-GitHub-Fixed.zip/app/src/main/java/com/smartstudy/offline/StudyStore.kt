package com.smartstudy.offline

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues

class StudyStore(context: Context) : SQLiteOpenHelper(context, "study.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE chunks(id INTEGER PRIMARY KEY, document TEXT, page INTEGER, body TEXT)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY, body TEXT, kind TEXT, created INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addChunks(chunks: List<SourceChunk>) {
        writableDatabase.beginTransaction()
        try {
            chunks.forEach { c -> writableDatabase.insert("chunks", null, ContentValues().apply {
                put("document", c.document); if (c.page == null) putNull("page") else put("page", c.page); put("body", c.text)
            }) }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun chunks(): List<SourceChunk> {
        val out = mutableListOf<SourceChunk>()
        readableDatabase.rawQuery("SELECT document,page,body FROM chunks", null).use { c ->
            while(c.moveToNext()) out += SourceChunk(c.getString(0), if(c.isNull(1)) null else c.getInt(1), c.getString(2))
        }
        return out
    }
    fun saveNote(body: String, kind: String) {
        writableDatabase.insert("notes", null, ContentValues().apply { put("body",body); put("kind",kind); put("created",System.currentTimeMillis()) })
    }
}
